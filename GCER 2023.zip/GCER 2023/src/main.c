#include <stdlib.h>
#include <math.h>
#include <constants.h>
#include <helper.h>
#include <servo.h>
#include <demo.h>
#include <UNIVERSAL.h>
#include <kipr/wombat.h>
#include <run_functions.h>
int main(){
    get_red_cube();
    spin_motor(0,2420,500);
    set_wheel_ticks(2420,2415);
    d_drive(50,50);
    d_right_turn(90, 500,0);
    spin_motor(0,2420,500);
    return 0;
}
//d_drive(float distance, float speed)
//d_line_follow(float distance, float speed, int port, char side)
//d_right_turn(float degree, float speed, double radius)
//d_left_turn(float degree, float speed, double radius)