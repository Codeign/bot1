#include <stdlib.h>
#include <math.h>
#include <constants.h>
#include <helper.h>
#include <servo.h>
#include <demo.h>
#include <UNIVERSAL.h>
#include <kipr/wombat.h>

void set_wheel_ticks(int left, int right){
    left_wheel_tpr = left;
    right_wheel_tpr = right;
    left_wheel_tpc = left/wheel_circumference;
    right_wheel_tpc = right/wheel_circumference;
    if(right_wheel_tpc > left_wheel_tpc){
        max_drive_speed = 1402/right_wheel_tpc;
    }else{
        max_drive_speed = 1402/left_wheel_tpc;
    }
    //printf("max drive speed is %f\n",max_drive_speed);
}
void spin_motor(int port, int ticks, int speed){
    cmpc(port);
    while(abs(gmpc(port)) < ticks){
        mav(port, speed);
    }
    mav(port,0);
    msleep(20);
}
void reckless_drive(float distance, int speed){
    cmpc(right_wheel);
    while(abs(gmpc(right_wheel)) < distance * 83){
        mav(right_wheel, speed);
        mav(left_wheel, speed);
        msleep(5);
    }
    mav(right_wheel, 0);
    mav(left_wheel, 0);
    msleep(20);
}
void reckless_turn(float degree, int speed){
    cmpc(right_wheel);
    float distance = degree*(pi/180)*(distance_between_wheels/2)*83;
    while(abs(gmpc(right_wheel)) < distance){
        mav(right_wheel, -speed);
        mav(left_wheel, speed);
        msleep(5);
    }
    mav(right_wheel, 0);
    mav(left_wheel, 0);
    msleep(20);
}
//an_to_wheel = 16.8275

double servo_start_time;
void d_drive(float distance, float speed){
    
    if(speed > max_drive_speed){
        speed = max_drive_speed;
    }
    float r_tps = right_wheel_tpc * speed;
    float l_tps = left_wheel_tpc *speed;
    float r_speed = (r_tps+2)/1.08;
    float l_speed = (l_tps+2)/1.08;
    clear_wheels();
    float distance_traveled = 0;
    int i = 0;
    float multiplier = 0;
    double x = 0;
    while(fabs(distance_traveled) < distance){
        
        mav(right_wheel, calculate_speed_ramp(distance,fabs(distance_traveled))*r_speed+10);
        mav(left_wheel, calculate_speed_ramp(distance,fabs(distance_traveled))*l_speed+10);
        msleep(10);
        for(i = 0; i < 4; i ++){
            if(servo_desired[i] != -1){ 
                if(seconds() < servo_finish_time[i] && servo_current[i] != servo_desired[i]){
                    x = (seconds()-servo_start_time)/(servo_finish_time[i]-servo_start_time);  
                    float total_dist = servo_desired[i]-servo_current[i];
                    float sqt = x*x;
                    multiplier = sqt/(2.0 * (sqt-x)+1.0);
                    //printf("%f\n",servo_current[i] + (total_dist*multiplier));
                    set_servo_position(i,servo_current[i] + (total_dist*multiplier));
                }
            }
        }
        distance_traveled = (gmpc(right_wheel)/right_wheel_tpc+gmpc(left_wheel)/left_wheel_tpc)/2;

    }
}

void d_line_follow(float distance, float speed, int port, char side){
    //printf("main\n");
    clear_wheels();
    int prev_right_ticks = 0;
    int prev_left_ticks = 0;
    long double local_x = 0;
    long double local_y = 0;
    long double local_theta = 0;
    if(speed > max_drive_speed){
        speed = max_drive_speed;
    }
    float tps = ((right_wheel_tpc+left_wheel_tpc)/2)*speed;
    float target_speed = (tps + 2)/1.08;
    distance = distance*0.975609756;
    while(local_y < distance){
        long double radius = line_follow_calculate_radius(grey_value-analog(port), maximum_line_follow_radius, minimum_line_follow_radius);
        if(side == 'r'){radius = -radius;}
        float *speeds = calculate_wheel_speed(radius,target_speed);
        mav(0,*(speeds+1)*calculate_speed_ramp(distance,local_y));//left wheel
        mav(1,*speeds*calculate_speed_ramp(distance,local_y));//right wheel
        msleep(30);
        float rmt = (gmpc(right_wheel)-prev_right_ticks)/right_wheel_tpc;
        float lmt = (gmpc(left_wheel)-prev_left_ticks)/left_wheel_tpc;
        float arc_length = (rmt+lmt)/2;
        prev_right_ticks = gmpc(right_wheel);
        prev_left_ticks = gmpc(left_wheel);
        double theta = arc_length/radius;
        long double a = (cos(theta)*radius)-radius;
        long double b = sin(theta)*radius;
        long double c = sqrt((a*a)+(b*b));
        a = sqrt(a*a);
        long double angle_a = asin(a/c);
        long double angle_y = (pi/2) - local_theta + angle_a;
        local_theta += theta;
        local_y += sin(angle_y)*c;
        local_x += sqrt((c*c)-(local_y*local_y));
        if(isnan(local_y)){
            local_y = 0.01;
        }
    }
}


void d_right_turn(float degree, float speed, double radius){
    float radians = (degree)/57.296;
	clear_wheels();
    float right_radius = radius - (distance_between_wheels/2); 
    float left_radius = radius + (distance_between_wheels/2);
    float right_arc = right_radius*radians*right_wheel_tpc;
    float left_arc = left_radius*radians*left_wheel_tpc;
    float right_speed, left_speed;
    if(radius == 0){
        right_speed = -speed;
        left_speed = speed;
    }else if(radius > 0){
        left_speed = speed;
        right_speed = (right_arc*speed)/left_arc;
    }else{
        right_speed = -speed;
        left_speed = -(left_arc*speed)/right_arc;
    }
	float mod = 0;
    double start = seconds();
    while(abs(gmpc(right_wheel)) < fabs(right_arc) || abs(gmpc(left_wheel)) < fabs(left_arc)){
        mod = calculate_speed_ramp(fabs(left_arc)/left_wheel_tpc, abs(gmpc(left_wheel))/left_wheel_tpc);
        if(fabs(right_arc) > fabs(left_arc)){
            mod = calculate_speed_ramp(fabs(right_arc)/right_wheel_tpc, fabs(gmpc(right_wheel))/right_wheel_tpc);
        }
        mav(right_wheel, (mod*right_speed)-150);
        mav(left_wheel, (mod*left_speed)+150);
        msleep(15);
        step_servos(seconds()-start);
        start = seconds();
    }
    mav(right_wheel,0);
    mav(left_wheel,0);
}

void d_left_turn(float degree, float speed, double radius){   
    float radians = (degree)/57.296;
	clear_wheels();
    float right_radius = radius + (distance_between_wheels/2); 
    float left_radius = radius - (distance_between_wheels/2);
    float right_arc = right_radius*radians*right_wheel_tpc;
    float left_arc = left_radius*radians*left_wheel_tpc;
    float right_speed, left_speed;
    if(radius == 0){
        right_speed = speed;
        left_speed = -speed;
    }else if(radius > 0){
        right_speed = speed;
        left_speed = (left_arc*speed)/right_arc;
    }else{
        left_speed = -speed;
        right_speed = -(right_arc*speed)/left_arc;
    }
	float mod = 0;
    double start = seconds();
    while(abs(gmpc(right_wheel)) < fabs(right_arc) || abs(gmpc(left_wheel)) < fabs(left_arc)){
        mod = calculate_speed_ramp(fabs(left_arc)/left_wheel_tpc, abs(gmpc(left_wheel))/left_wheel_tpc);
        if(fabs(right_arc) > fabs(left_arc)){
            mod = calculate_speed_ramp(fabs(right_arc)/right_wheel_tpc, fabs(gmpc(right_wheel))/right_wheel_tpc);
        }
        mav(right_wheel, mod*right_speed);
        mav(left_wheel, mod*left_speed);
        msleep(15);
        step_servos(seconds()-start);
        start = seconds();
    }
	mav(right_wheel,0);
    mav(left_wheel,0);
}
