#include <stdlib.h>
#include <math.h>
#include <constants.h>
#include <helper.h>
#include <servo.h>
#include <demo.h>
#include <UNIVERSAL.h>
#include <kipr/wombat.h>
#include <run_functions.h>
int get_red_cube(){
return 1;
}