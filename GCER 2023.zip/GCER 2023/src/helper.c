#include <stdlib.h>
#include <math.h>
#include <constants.h>
#include <helper.h>
#include <servo.h>
#include <demo.h>
#include <UNIVERSAL.h>
#include <kipr/wombat.h>
typedef struct{
    double x;
    double y;
    double theta;
}position;
////////////////////////////////////////////////////////////////
//HELPER FUNCTIONS
////////////////////////////////////////////////////////////////
void viprint(int val){
    printf("value: %d\n",val);
}
void vfprint(float val){
    printf("value: %f\n",val);
}
float lerp(float start, float finish, float progress){
    return start + (finish-start)*progress;
}
float analog_avg(int port, int loops){
    int mass = 0;
    int i;
    for(i = 0; i < loops; i ++){
        mass += analog(port);
    }
    return mass/loops;
}

void clear_wheels(){
    cmpc(right_wheel);
    cmpc(left_wheel);
}
//change the distance that the robot accels and deccels
void set_accel_window(float distance){
    accel_distance = distance;
}



void light(int port){
    printf("press the button when light is ON");
    while(!a_button()){
        msleep(3);
    }
    float on = analog_avg(port,5);
   	vfprint(on);
    msleep(1000);
    printf("press the button when light is OFF");
    while(!a_button()){
        msleep(3);
    }
    float off = analog_avg(port,5);
  	float gry = (on+off)/2;
    printf("Grey Value is %f. now waiting for light\n", gry);
    while(analog(port) > gry){
        msleep(3);
    }
    

}

//function that takes the error value received from the line follow sensor and gives back a radius for the turn
float line_follow_calculate_radius(int error_value, float max_radius, float min_radius){
    //NOTE: white means positive error and black means negative error FOR LEFT SIDE LINE FOLLOW
    float error_modifier = black_and_white_diff*0.4;
    if(error_value > error_modifier){
        return -min_radius;
    }else if(error_value < -error_modifier){
        return min_radius;
    }else if(error_value < 0){
        return (error_value*((max_radius-min_radius)/error_modifier)) + max_radius;
    }else{
        return (error_value*((max_radius-min_radius)/error_modifier)) - max_radius;
    }
}

//takes the speed of the origin and get the individual wheel speeds
float * calculate_wheel_speed(float radius, float speed){
    static float speeds[2];
    float theta = speed/radius;
    speeds[0] = theta * (radius-(distance_between_wheels*0.5));
    speeds[1] = theta * (radius+(distance_between_wheels*0.5));
    return speeds;
}
position calculate_location_change(double right_movement, double left_movement, double theta, float speed){
    position output;
    double dist_travelled = (right_movement+left_movement)/2;
    if(right_movement == left_movement){
        output.theta = 0;
        if(theta != 0){
            double loc_x = sin(fabs(theta))*dist_travelled;
            double loc_y = sin((pi/2)-fabs(theta))*dist_travelled;
            if(speed > 0){output.y = loc_y;}else{output.y = -loc_y;}
            if(theta < 0){output.x = -loc_x;}else{output.x = loc_x;}
        }else{
            output.x = 0;
            if(speed > 0){output.y = dist_travelled;}else{output.y = -dist_travelled;}
        }
    }else{
        double wr = right_movement/left_movement;//wheel ratio
        double radius = ((wr*11.75)+11.75)/(1-wr);//this contsant might be the distance between wheels for the create. If this function is used for demo line follow I will need to check it
        double alpha = dist_travelled/radius;
        double a = (cos(alpha)*radius)-radius;
        double b = sin(alpha)*radius;
        double c = sqrt((a*a)+(b*b));
        double a_ang = asin(abs(a)/c);
        output.theta = alpha;
        double y_ang = (pi/2)-alpha+a_ang;
        double local_y = sin(y_ang)*c;
        double local_x = sqrt((c*c)-(local_y*local_y));
        if(right_movement > left_movement){output.x = -local_x;}else{output.x = local_x;}
        if(speed > 0){output.y = local_y;}else{output.y = -local_y;}
    }
    return output;
}
void start_chain(int size){
    chain_size = size;
    chain = size;
}

float calculate_speed_ramp(float final_dist, float current_dist){ 
    if(current_dist < accel_distance && (chain_size == chain || chain < 1)){
        float norm_x = current_dist/(accel_distance);


        float tween = sin(pi/2*norm_x);
        if(tween < 0.2){
            return 0.2;
        }
        return tween;

    }else if(current_dist > final_dist - accel_distance && chain < 2){
        float norm_x = (final_dist-current_dist-(accel_distance))/(accel_distance); 
        return cos((pi/2) * norm_x);
    }else{
        return 1;
    } 
}
