#include <stdlib.h>
#include <math.h>
#include <constants.h>
#include <helper.h>
#include <servo.h>
#include <demo.h>
#include <UNIVERSAL.h>
#include <kipr/wombat.h>
double servo_time_elapsed[4] = {0,0,0,0};
void update_servos(){
    servo_current[0] = get_servo_position(0);
    servo_current[1] = get_servo_position(1);
    servo_current[2] = get_servo_position(2);
    servo_current[3] = get_servo_position(3);
}
void clear_servos(){
    servo_desired[0] = -1;
    servo_desired[1] = -1;
    servo_desired[2] = -1;
    servo_desired[3] = -1;
}
void load_servo(int port, int position, int speed){
    servo_desired[port] = position;
    servo_time[port] = speed;
    update_servos();
}

void servo(int port,int position,int speed){
    mav(right_wheel,0);
    mav(left_wheel,0);
    msleep(10);
    servo_desired[port] = position;
    servo_time[port] = speed;
    update_servos();
    int exit = 0;
    int i = 0;
    float start = seconds();
    for(i = 0; i < 4;i ++){
        servo_finish_time[i] = servo_time[i] + start;
    }
    float multiplier = 0;
    double x = 0;
    while(exit == 0){
        exit = 1;
        for(i = 0; i < 4; i ++){
            if(servo_desired[i] != -1){ 
                if(seconds()-start < servo_time[i] && servo_current[i] != servo_desired[i]){
                    exit = 0;
                    x = (seconds()-start)/(servo_finish_time[i]-start);
                    float total_dist = servo_desired[i]-servo_current[i];
                    float sqt = x*x;
                    multiplier = sqt/(2.0 * (sqt-x)+1.0);
                    set_servo_position(i,servo_current[i] + (total_dist*multiplier));
                }else{
                    set_servo_position(i,servo_desired[i]);
                }
            }
        }
        msleep(5);
    }
    clear_servos();
}
void step_servos(double time){
    int i = 0;
    float multiplier = 0;
    double x = 0;
    for(i = 0; i < 4; i ++){
            if(servo_desired[i] != -1){
                if(servo_time_elapsed[i] < servo_time[i] && servo_current[i] != servo_desired[i]){
                    x = (servo_time_elapsed[i])/(servo_time[i]);
                    float total_dist = servo_desired[i]-servo_current[i];
                    float sqt = x*x;
                    multiplier = sqt/(2.0 * (sqt-x)+1.0);
                    set_servo_position(i,servo_current[i] + (total_dist*multiplier));
                    printf("%lf\n",15.0/1000.0);
                    servo_time_elapsed[i] += time;
                    
                }else{
                    set_servo_position(i,servo_desired[i]);
                }
            }
        }
}