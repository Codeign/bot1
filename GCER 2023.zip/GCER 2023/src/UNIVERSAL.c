#include <stdlib.h>
#include <math.h>
#include <constants.h>
#include <helper.h>
#include <servo.h>
#include <demo.h>
#include <UNIVERSAL.h>
#include <kipr/wombat.h>
#define create_in_use 0
void drive(float distance, int speed){
    //printf("////////////drive/////////////////\n");
    if(create_in_use == 0){
        d_drive(distance,speed);
    }else{
        //r_drive(distance, speed);
    }
    chain --;
}

void line_follow(float distance, int speed, int port, char side){
    if(create_in_use == 0){
        d_line_follow(distance, speed, port, side);
    }else{
        //r_line_follow(distance, speed, port, side);
    }
    chain --;
}

void right_turn(float degree, float speed, double radius){
    //printf("////////////right turn/////////////////\n");
    if(create_in_use == 0){
        d_right_turn(degree, speed, radius);
    }else{
        //r_turn(degree, speed, radius, 'r');
    }
    chain --;
}

void left_turn(float degree, float speed, double radius){
    if(create_in_use == 0){
        d_left_turn(degree, speed, radius);
    }else{
        //r_turn(degree, speed, radius, 'l');
    }
    chain --;
}

void square(int speed){
    if(create_in_use == 0){
    }else{
        //create_square_up(speed);
    }
    chain --;
}

    